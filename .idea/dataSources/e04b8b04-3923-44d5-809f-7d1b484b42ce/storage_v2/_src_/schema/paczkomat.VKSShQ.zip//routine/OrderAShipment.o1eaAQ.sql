create
    definer = root@localhost procedure OrderAShipment(IN your_email varchar(100), IN recipient_name varchar(100),
                                                      IN recipient_surname varchar(100),
                                                      IN recipient_address varchar(100),
                                                      IN recipient_phone_number varchar(20),
                                                      IN recipient_email varchar(100),
                                                      IN package_size enum ('S', 'M', 'L'))
begin

declare recipient_id VARCHAR(100);
declare rID int;
declare clientID int;
declare reception_place VARCHAR(30);
declare consignment_place VARCHAR(30);
declare tmpID int;

select count(shipment_id) into tmpID from shipments;
select client_address into reception_place from clients where client_email like recipient_email limit 1;
select client_address into consignment_place from clients where client_email like your_email limit 1;
select client_id into rID from clients where client_email like recipient_email limit 1;
select client_id into clientID from clients where client_email like your_email limit 1;
select CAST(rID as char(50)) into recipient_id;

if ((checkLocker(package_size, consignment_place) = true) and (checkEmail(recipient_email) = true)) then
begin
insert into shipments (shipment_id, shipment_package_size, shipment_price, shipment_consignment_place, shipment_reception_place, 
shipment_status, shipment_consignment_date, shipment_recipient_id, client_id, automat_address)
values ((tmpID+1),package_size, returnPrice(package_size), consignment_place, reception_place, 'Sent', curdate(), recipient_id, clientID, consignment_place);

call paczkomat.setLocker(consignment_place, 'putIn', package_size);
end;
elseif ((checkLocker(package_size, consignment_place) = false) and (checkEmail(recipient_email) = true)) then
SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'No more empty lockers in your automat left. We are sorry, come back later.';
elseif ((checkLocker(package_size, consignment_place) = true) and (checkEmail(recipient_email) = false)) then
begin
insert into shipments(shipment_id,shipment_package_size, shipment_price, shipment_consignment_place, shipment_reception_place, 
shipment_status, shipment_consignment_date, shipment_recipient_id, client_id, automat_address) 
values ((tmpID+1),package_size, returnPrice(package_size), consignment_place, recipient_address, 'Sent', curdate(), concat("tmp",(tmpID+1)), clientID, consignment_place);

insert into temporaryclients(shipment_id, tmp_client_name, tmp_client_surname,
tmp_client_address, tmp_client_email, tmp_client_phone_number) 
values ((tmpID+1), recipient_name, recipient_surname, recipient_address, recipient_email, recipient_phone_number);

call paczkomat.setLocker(consignment_place, 'putIn', package_size);
end;
else
SIGNAL SQLSTATE '45000'
			SET MESSAGE_TEXT = 'No more empty lockers in your automat left. We are sorry, come back later.';
end if;
end;

