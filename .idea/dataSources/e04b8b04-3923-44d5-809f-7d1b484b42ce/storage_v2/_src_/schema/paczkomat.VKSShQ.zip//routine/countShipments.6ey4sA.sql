create
    definer = root@localhost function countShipments() returns int
begin

declare countS int;
declare countM int;
declare countL int;
declare totalAmountOfDailyShipments int;

select count(*) into countS from shipments where shipment_package_size like 'S';
select count(*) into countM from shipments where shipment_package_size like 'M';
select count(*) into countL from shipments where shipment_package_size like 'L';

set totalAmountOfDailyShipments = countS + countM + countL;
return totalAmountOfDailyShipments;
end;

