create
    definer = root@localhost function countDailyShipments(selectDay date) returns int
begin

declare countS int;
declare countM int;
declare countL int;
declare totalAmountOfDailyShipments int;

select count(*) into countS from shipments where DATE(shipment_consignment_date) like selectDay and shipment_package_size like 'S';
select count(*) into countM from shipments where DATE(shipment_consignment_date) like selectDay and shipment_package_size like 'M';
select count(*) into countL from shipments where DATE(shipment_consignment_date) like selectDay and shipment_package_size like 'L';

set totalAmountOfDailyShipments = countS + countM + countL;
return totalAmountOfDailyShipments;
end;

