create definer = root@localhost view customerview as
select `s`.`shipment_id`                               AS `ID`,
       concat(`c`.`client_name`, `c`.`client_surname`) AS `recipient`,
       `s`.`shipment_status`                           AS `ShipmentStatus`,
       `s`.`shipment_consignment_date`                 AS `ConsignmentDate`,
       `s`.`shipment_reception_date`                   AS `ReceptionDate`,
       `s`.`shipment_package_size`                     AS `Size`,
       `s`.`automat_address`                           AS `automat_address`
from (`paczkomat`.`shipments` `s`
         join `paczkomat`.`clients` `c` on ((`s`.`client_id` = `c`.`client_id`)));

