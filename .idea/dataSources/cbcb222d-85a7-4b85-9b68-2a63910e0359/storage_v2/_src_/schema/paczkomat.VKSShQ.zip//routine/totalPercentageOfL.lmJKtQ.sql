create
    definer = root@localhost function totalPercentageOfL() returns decimal(7, 2)
begin

declare countL int;
declare Lpercentage decimal(7,2);
declare allShipments decimal(7,2);
select count(*) into countL from shipments where shipment_package_size like 'L';
select paczkomat.countShipments() into allShipments;
set Lpercentage = (countL/allShipments)*100;
return Lpercentage;
end;

