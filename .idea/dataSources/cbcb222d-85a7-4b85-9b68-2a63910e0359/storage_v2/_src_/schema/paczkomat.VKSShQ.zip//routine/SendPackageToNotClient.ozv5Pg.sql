create
    definer = root@localhost procedure SendPackageToNotClient(IN your_email varchar(100),
                                                              IN package_size enum ('S', 'M', 'L'),
                                                              IN recipient_name varchar(100),
                                                              IN recipient_surname varchar(100),
                                                              IN recipient_address varchar(100),
                                                              IN recipient_email varchar(100),
                                                              IN recipient_phone_number varchar(20))
begin
declare clientID int;
declare consignment_place VARCHAR(30);
select client_address into consignment_place from clients where client_email like your_email;
select client_id into clientID from clients where client_email like your_email;

if (checkLocker(package_size, consignment_place) = true) then
begin
insert into shipments(shipment_package_size, shipment_price, shipment_consignment_place, shipment_reception_place, 
shipment_status, shipment_consignment_date, shipment_recipient_id, client_id, automat_address) 
values (package_size, returnPrice(package_size), consignment_place, recipient_address, 'Sent', curdate(), clientID, clientID, consignment_place);

insert into temporaryclients(client_id, tmp_client_name, tmp_client_surname,
tmp_client_address, tmp_client_email, tmp_client_phone_number) 
values (clientID, recipient_name, recipient_surname, recipient_address, recipient_email, recipient_phone_number);

call paczkomat.setLocker(consignment_place, 'putIn', package_size);
end;
end if;
end;

