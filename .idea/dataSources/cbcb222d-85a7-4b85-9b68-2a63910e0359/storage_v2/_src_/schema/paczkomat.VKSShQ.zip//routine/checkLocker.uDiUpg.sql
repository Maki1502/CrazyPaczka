create
    definer = root@localhost function checkLocker(package_size enum ('S', 'M', 'L'), automatAddress varchar(30)) returns tinyint(1)
begin
declare locker_status boolean;
declare S_lock int;
declare M_lock int;
declare L_lock int;
select S_lockers_amount into S_lock from automats where automats.automat_address = automatAddress;
select M_lockers_amount into M_lock from automats where automats.automat_address = automatAddress;
select L_lockers_amount into L_lock from automats where automats.automat_address = automatAddress;

if ((package_size like 'S') and (S_lock > 0)) then 
set locker_status = true;
elseif ((package_size like 'M') and (M_lock > 0)) then 
set locker_status = true;
elseif ((package_size like 'L') and (L_lock > 0)) then 
set locker_status = true;
else
set locker_status = false;
end if;
return locker_status;
end;

