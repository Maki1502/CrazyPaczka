create
    definer = root@localhost function totalPercentageOfS() returns decimal(7, 2)
begin

declare countS int;
declare Spercentage decimal(7,2);
declare allShipments decimal(7,2);
select count(*) into countS from shipments where shipment_package_size like 'S';
select paczkomat.countShipments() into allShipments;
set Spercentage = (countS/allShipments)*100;
return Spercentage;
end;

