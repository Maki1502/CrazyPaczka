create
    definer = root@localhost function totalPercentageOfM() returns decimal(7, 2)
begin

declare countM int;
declare Mpercentage decimal(7,2);
declare allShipments decimal(7,2);
select count(*) into countM from shipments where shipment_package_size like 'M';
select paczkomat.countShipments() into allShipments;
set Mpercentage = (countM/allShipments)*100;
return Mpercentage;
end;

