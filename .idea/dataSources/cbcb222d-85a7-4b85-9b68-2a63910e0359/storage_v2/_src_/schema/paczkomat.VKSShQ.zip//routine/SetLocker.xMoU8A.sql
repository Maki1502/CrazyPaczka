create
    definer = root@localhost procedure SetLocker(IN automatAddress varchar(30),
                                                 IN transactionType enum ('putIn', 'pickUp'),
                                                 IN package_size enum ('S', 'M', 'L'))
begin
declare Ttype int;
select S_lockers_amount from automats where automat_address like automatAddress;
select M_lockers_amount from automats where automat_address like automatAddress;
select L_lockers_amount from automats where automat_address like automatAddress;

if (transactionType like 'putIn') then 
set Ttype = -1;
elseif  (transactionType like 'pickUp') then 
set Ttype = 1;
end if;

if (package_size like 'S') then 
update automats
set S_lockers_amount = S_lockers_amount + Ttype
where automat_address like automatAddress;
elseif (package_size like 'M') then 
update automats
set M_lockers_amount = M_lockers_amount + Ttype
where automat_address like automatAddress;
elseif (package_size like 'L') then 
update automats
set L_lockers_amount = L_lockers_amount + Ttype
where automat_address like automatAddress;
end if;
end;

