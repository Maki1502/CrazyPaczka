create
    definer = root@localhost procedure PickUpPackage(IN shipmentID int)
begin
declare reception_place VARCHAR(30);
declare package_size VARCHAR(30);
select shipment_reception_place into reception_place from shipments where shipment_id like shipmentID;

begin
update shipments
set shipment_status = 'Received'
where shipment_id like shipmentID;
update shipments
set automat_address = null
where shipment_id like shipmentID;
update shipments
set shipment_reception_date = curdate()
where shipment_id like shipmentID;
call paczkomat.setLocker(reception_place, 'pickUp', package_size);
end;

end;

