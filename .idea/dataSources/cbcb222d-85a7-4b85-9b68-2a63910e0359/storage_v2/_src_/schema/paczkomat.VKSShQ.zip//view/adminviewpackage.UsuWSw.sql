create definer = root@localhost view adminviewpackage as
select `paczkomat`.`shipments`.`shipment_id`               AS `ID`,
       `paczkomat`.`shipments`.`shipment_consignment_date` AS `ConsDate`,
       `paczkomat`.`shipments`.`shipment_reception_date`   AS `RecDate`,
       `paczkomat`.`shipments`.`client_id`                 AS `SenderId`,
       `paczkomat`.`shipments`.`shipment_recipient_id`     AS `ReceiverID`,
       `paczkomat`.`shipments`.`shipment_price`            AS `Price`,
       `paczkomat`.`shipments`.`shipment_status`           AS `packStatus`
from `paczkomat`.`shipments`;

