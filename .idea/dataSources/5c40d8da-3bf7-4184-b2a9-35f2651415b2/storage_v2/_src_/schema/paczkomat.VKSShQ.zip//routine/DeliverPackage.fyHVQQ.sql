create
    definer = root@localhost procedure DeliverPackage(IN shipmentID int)
begin
declare reception_place VARCHAR(30);
declare package_size VARCHAR(30);
select shipment_reception_place from shipments where shipment_id like shipmentID;
select shipment_reception_place into reception_place from shipments where shipment_id like shipmentID;
select shipment_package_size from shipments where shipment_id like shipmentID;
select shipment_package_size into package_size from shipments where shipment_id like shipmentID;

if (checkLocker(package_size, reception_place) = true) then
begin
update shipments
set shipment_status = 'Arrived'
where shipment_id like shipmentID;

update shipments
set automat_address = reception_place
where shipment_id like shipmentID;

update shipments
set shipment_delivery_date = curdate()
where shipment_id like shipmentID;

call paczkomat.setLocker(reception_place, 'putIn', package_size);
end;
end if;
end;

