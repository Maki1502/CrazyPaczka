create
    definer = root@localhost function returnPrice(package_size enum ('S', 'M', 'L')) returns decimal(5, 2)
begin
declare price decimal(5,2);

if package_size like 'S' then
set price = 11.99;
elseif package_size like 'M' then
set price = 12.99;
elseif package_size like 'L' then
set price = 14.99;
end if;
return price;
end;

