create
    definer = root@localhost procedure SendPackage(IN shipmentID int)
begin
declare consignment_place VARCHAR(30);
declare package_size VARCHAR(30);
declare shipStat VARCHAR(30);
select shipment_consignment_place into consignment_place from shipments where shipment_id like shipmentID;
select shipment_package_size into package_size from shipments where shipment_id like shipmentID;
select shipment_status into shipStat from shipments where shipment_id like shipmentID;


if (shipStat like 'Sent') then
begin
update shipments
set shipment_status = 'OnMyWay'
where shipment_id like shipmentID;

update shipments
set automat_address = null
where shipment_id like shipmentID;

update shipments
set shipment_sending_date = curdate()
where shipment_id like shipmentID;

call paczkomat.setLocker(consignment_place, 'pickUp', package_size);
end;
else
SIGNAL SQLSTATE '47000'
			SET MESSAGE_TEXT = 'Locker is broken :) probably courier dropped some packages to hard.';
end if;
end;

