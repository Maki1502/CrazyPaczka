create
    definer = root@localhost function totalProfit() returns decimal(7, 2)
begin

declare countS int;
declare countM int;
declare countL int;
declare totalAmountOfMoney decimal(7,2);

select count(*) into countS from shipments where shipment_package_size like 'S';
select count(*) into countM from shipments where shipment_package_size like 'M';
select count(*) into countL from shipments where shipment_package_size like 'L';

set totalAmountOfMoney = (countS*returnPrice('S')) + (countM*returnPrice('M')) + (countL*returnPrice('L'));
return totalAmountOfMoney;
end;

