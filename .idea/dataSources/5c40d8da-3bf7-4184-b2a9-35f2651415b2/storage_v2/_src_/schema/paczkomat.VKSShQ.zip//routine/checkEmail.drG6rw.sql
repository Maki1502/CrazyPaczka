create
    definer = root@localhost function checkEmail(email varchar(100)) returns tinyint(1)
begin
declare position decimal(5,2);
declare newlist VARCHAR(1000);
declare contain boolean;
select group_concat(client_email) into newlist from clients;
select find_in_set(email , newlist) into position;

if (position > 0) then 
set contain = true;
else
set contain = false;
end if;
return contain;
end;

