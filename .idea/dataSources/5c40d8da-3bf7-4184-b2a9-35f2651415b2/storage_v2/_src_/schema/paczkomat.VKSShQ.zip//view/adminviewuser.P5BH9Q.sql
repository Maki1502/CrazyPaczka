create view adminviewuser as
select `paczkomat`.`clients`.`client_id`           AS `ID`,
       `paczkomat`.`clients`.`client_name`         AS `clName`,
       `paczkomat`.`clients`.`client_surname`      AS `clSurname`,
       `paczkomat`.`clients`.`client_address`      AS `address`,
       `paczkomat`.`clients`.`client_email`        AS `mail`,
       `paczkomat`.`clients`.`client_phone_number` AS `PhNumber`
from `paczkomat`.`clients`;

