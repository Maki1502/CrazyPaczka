create
    definer = root@localhost procedure addClient(IN c_name varchar(100), IN c_surname varchar(100),
                                                 IN c_address varchar(100), IN c_email varchar(100),
                                                 IN c_phone_number varchar(20), IN c_password varchar(100))
begin
if ((checkTemporaryEmail(c_email) = true) and (checkEmail(c_email) = false)) then
insert into clients(client_name, client_surname, client_address, client_email, client_phone_number, client_password) 
values (c_name, c_surname, c_address, c_email, c_phone_number, c_password);
DELETE FROM paczkomat.temporaryclients WHERE tmp_client_email like c_email;

elseif ((checkTemporaryEmail(c_email) = false) and (checkEmail(c_email) = false)) then
insert into clients(client_name, client_surname, client_address, client_email, client_phone_number, client_password) 
values (c_name, c_surname, c_address, c_email, c_phone_number, c_password);
else
SIGNAL SQLSTATE '46000'
			SET MESSAGE_TEXT = 'There was a problem creating your account. Account with that email address already exists.';
end if;
end;

